import { initDisplayMode } from './utils/displayMode.js';

document.addEventListener('DOMContentLoaded', () => {
    initDisplayMode();
});