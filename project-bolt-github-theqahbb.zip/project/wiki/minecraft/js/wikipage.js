import {
    resolveContent,
    renderResolvedMarkdown,
    renderResolvedText,
    renderCoords,
    renderDatetime,
    renderTimestamp,
    renderResolvedMultivalueBlock,
    renderResolvedMedia,
    renderResolvedTimeline,
    renderResolvedImgTable,
    renderResolvedDatetime,
    getNestedValue,
    mergeFromKeyPath,
    getHeaderClickableId,
    getFirstParentWithClass
} from '/wiki/minecraft/js/wikipage_parsers.js';

const Constants = {
    "markdown": {
        "__axo77_bluemap__": "http://test.bluemap.axow.se/"
    }
};

export async function renderWikiPage(pagedata,container) {
    // Clear container once at start
    container.innerHTML = "";

    // Prepare URL for pathing
    const current_url = new URL(window.location.href);
    const base_url = current_url.pathname.split('/').slice(0, -1).join('/');

    // Create DOM structure asynchronously
    const structure = await createDOMStructure(pagedata, base_url);
    container.appendChild(structure);

    // Fill content
    await Promise.all([
        fillInfobox(pagedata, structure.querySelector('.wikipage-infobox')),
        fillSections(pagedata, structure),
        fillComments(pagedata, structure.querySelector('.wikipage-comment-section'))
    ]);
}

async function createDOMStructure(pagedata, base_url) {
    const template = document.createElement('div');
    template.innerHTML = `
        <header class="wikipage-header">
            <span class="wikipage-header-pathing">
                / ${await generatePathing(pagedata, base_url)}
            </span>
            <h1 class="wikipage-header-title"></h1>
            <div class="wikipage-header-shortcuts"></div>
        </header>
        <main class="wikipage-main">
            <section class="wikipage-introduction-section">
                <div class="wikipage-left">
                    <div class="wikipage-introduction-text"></div>
                    <div class="wikipage-totitle">
                        <p class="wikipage-totitle-loading">Parsing Wikipage...</p>
                    </div>
                </div>
                <aside class="wikipage-right">
                    <div class="wikipage-infobox"></div>
                    <div class="wikipage-mediainfobox"></div>
                </aside>
            </section>
            <section class="wikipage-content-section"></section>
            <section class="wikipage-sources-section">
                <h2 class="wikipage-sources-header">Sources</h2>
            </section>
            <section class="wikipage-comment-section">
                <h2 class="wikipage-comment-header">Comments</h2>
            </section>
        </main>
        <footer class="wikipage-footer">
            <details class="wikipage-pagesource">
                <summary>View PageSource (JSON)</summary>
                <pre>${JSON.stringify(pagedata, null, 2)}</pre>
            </details>
        </footer>
    `;
    return template;
}

async function generatePathing(pagedata, base_url) {
    const parts = [];
    
    if (pagedata.group) {
        parts.push(`<a class="wikipage-header-pathing-group" href="${base_url}/pages.html?filter_group=${pagedata.group}">${pagedata.group}</a>`);
    }
    
    if (pagedata.category) {
        parts.push(`<a class="wikipage-header-pathing-category" href="${base_url}/pages.html?filter_cat=${pagedata.category}">${pagedata.category}</a>`);
    } else {
        parts.push('...');
    }
    
    parts.push(`<a class="wikipage-header-pathing-page" href="${pagedata._sourcefile_}">${pagedata.page || 'page'}.json</a>`);
    
    return parts.join(' / ');
}

async function fillInfobox(pagedata, infobox) {
    if (pagedata.infobox) {
        const infoboxContent = await Promise.all(pagedata.infobox.map(async (entry) => {
            if (entry["MERGE:FROM"]) {
                entry = await mergeFromKeyPath(entry, pagedata);
            }
            return renderInfoboxEntry(entry, pagedata);
        }));
        infobox.innerHTML = infoboxContent.join('');
    }
}

async function renderInfoboxEntry(entry, pagedata) {
    switch(entry.type) {
        case "title":
            const titleText = await renderResolvedText(entry.content, pagedata);
            return `
                <div class="wikipage-infobox-title">
                    <h1 class="wikipage-infobox-title-content">${titleText}</h1>
                </div>
            `;

        case "banner":
            const bannerSrc = await resolveContent(entry.content, pagedata);
            return `
                <div class="wikipage-infobox-banner wikipage-media wikipage-media-image">
                    <figure>
                        <img src="${bannerSrc}" alt="banner image"/>
                        <figcaption class="wikipage-infobox-banner-figcaption"></figcaption>
                    </figure> 
                </div>
            `;

        case "banner_source":
            const bannerSource = await renderResolvedMarkdown(
                entry.content.replace(/__axo77_bluemap__/g, Constants.markdown.__axo77_bluemap__),
                pagedata
            );
            return `
                <div class="wikipage-infobox-banner-source">
                    ${bannerSource}
                </div>
            `;

        case "attribute":
            const attributeContent = await renderResolvedMarkdown(entry.content, pagedata);
            return `
                <div class="wikipage-infobox-attribute">
                    <b class="wikipage-infobox-attribute-title">${entry.title}</b>
                    <div class="wikipage-infobox-attribute-content">${attributeContent}</div>
                </div>
            `;

        case "attributed_profile":
            const profileText = await renderResolvedText(entry.profiles.join(", "), pagedata);
            return `
                <div class="wikipage-infobox-attribute wikipage-infobox-attribute-profile">
                    <b class="wikipage-infobox-attribute-title">${entry.title}</b>
                    <p class="wikipage-infobox-attribute-content attributed_profile has_profile_links has_article_links">${profileText}</p>
                </div>
            `;

        case "header":
            const headerText = await renderResolvedText(entry.content, pagedata);
            return `
                <div class="wikipage-infobox-header">
                    <h2 class="wikipage-infobox-header-content">${headerText}</h2>
                </div>
            `;

        case "attributed_location":
            const locationCoords = await renderCoords(entry.content);
            return `
                <div class="wikipage-infobox-attribute wikipage-infobox-attribute-location">
                    <b class="wikipage-infobox-attribute-title">${entry.title}</b>
                    <p class="wikipage-infobox-attribute-content attributed_location">${locationCoords}</p>
                </div>
            `;

        case "named_multivalue_attribute":
            const multivalueContent = await Promise.all(entry.content.map(async (subEntry) => {
                if (subEntry["MERGE:FROM"]) {
                    subEntry = await mergeFromKeyPath(subEntry, pagedata);
                }
                return `
                    <div class="wikipage-infobox-attribute-content attributed_named_multivalue">
                        ${await renderResolvedMultivalueBlock(subEntry, pagedata)}
                    </div>
                `;
            }));
            return `
                <div class="wikipage-infobox-attribute wikipage-infobox-attribute-named-multivalue">
                    <b class="wikipage-infobox-attribute-title">${entry.title}</b>
                    ${multivalueContent.join('')}
                </div>
            `;

        case "attributed_descripted_profiles":
            const profilesContent = await Promise.all(entry.value.map(async (profileEntry) => {
                if (profileEntry["MERGE:FROM"]) {
                    profileEntry = await mergeFromKeyPath(profileEntry, pagedata);
                }
                return `
                    <div class="wikipage-infobox-attribute-content attributed_descripted_profiles">
                        <p class="attributed_descripted_profiles_profile">${await resolveContent(profileEntry[0], pagedata)}</p>
                        <p class="attributed_descripted_profiles_description">${await renderResolvedText(profileEntry[1], pagedata)}</p>
                    </div>
                `;
            }));
            return `
                <div class="wikipage-infobox-attribute wikipage-infobox-attribute-descripted-profiles">
                    <b class="wikipage-infobox-attribute-title">${entry.title}</b>
                    ${profilesContent.join('')}
                </div>
            `;

        case "attributed_time":
            return `
                <div class="wikipage-infobox-attribute wikipage-infobox-attribute-time">
                    <b class="wikipage-infobox-attribute-title">${entry.title}</b>
                    <div class="wikipage-infobox-attribute-content attributed_time">
                        <p class="attributed_time_time wikipage-timestamp">${await renderTimestamp(entry.time, pagedata)}</p>
                        <div class="attributed_time_desc">${await renderResolvedMarkdown(entry.description, pagedata)}</div>
                    </div>
                </div>
            `;

        default:
            return '';
    }
}

async function fillSections(pagedata, container) {
    if (!pagedata.sections) return;

    const contentSection = container.querySelector('.wikipage-content-section');
    const introText = container.querySelector('.wikipage-introduction-text');
    const sourcesSection = container.querySelector('.wikipage-sources-section');
    const sourcesHeader = sourcesSection.querySelector('.wikipage-sources-header');

    await Promise.all(pagedata.sections.map(async (section) => {
        if (section["MERGE:FROM"]) {
            section = await mergeFromKeyPath(section, pagedata);
        }

        const sectionContent = await renderSection(section, pagedata);
        
        if (section.type === 'introduction') {
            introText.innerHTML += sectionContent;
        } else if (section.type === 'sources') {
            if (section.title && section.title !== "" && section.title !== null) {
                sourcesHeader.innerText = section.title;
            }
            sourcesSection.innerHTML += sectionContent;
        } else {
            contentSection.innerHTML += sectionContent;
        }
    }));
}

async function renderSection(section, pagedata) {
    switch(section.type) {
        case 'introduction':
            return `
                <div class="wikipage-introduction-text-content">
                    ${await renderResolvedMarkdown(section.content, pagedata)}
                </div>
            `;
            
        case 'text':
            return `
                <div class="wikipage-content-block wikipage-content-text">
                    <h2>${section.title}</h2>
                    <div>${await renderResolvedMarkdown(section.content, pagedata)}</div>
                </div>
            `;

        case 'media_grid':
            const mediaGridContent = await Promise.all(section.content.map(async (entry) => {
                if (entry["MERGE:FROM"]) {
                    entry = await mergeFromKeyPath(entry, pagedata);
                }
                return `
                    <div class="wikipage-mediagrid-block">
                        ${await renderResolvedMedia(entry, pagedata)}
                    </div>
                `;
            }));
            return `
                <div class="wikipage-content-block wikipage-content-mediagrid">
                    <h2>${section.title}</h2>
                    <div class="wikipage-mediagrid">
                        ${mediaGridContent.join('')}
                    </div>
                </div>
            `;

        case 'sources':
            const sourcesContent = await Promise.all(section.content.map(async (entry) => {
                if (entry["MERGE:FROM"]) {
                    entry = await mergeFromKeyPath(entry, pagedata);
                }
                return `
                    <a ${entry.href ? 'href="'+(await resolveContent(entry.href, pagedata))+'"' : ''} class="a-reset wikipage-source-row wikipage-source-row-href wikipage-reference-note">
                        <i class="wikipage-source-row-id wikipage-reference-note-id">${entry.id ? entry.id : ''}.</i>
                        <span class="wikipage-source-row-text wikipage-reference-note-text">${await renderResolvedText(entry.text, pagedata)}</span>
                        <p class="wikipage-source-row-time wikipage-timestamp wikipage-reference-note-time">(${await renderResolvedDatetime(entry.time, pagedata)})</p>
                    </a>
                `;
            }));
            return sourcesContent.join('');

        case 'timeline':
            return `
                <div class="wikipage-content-block wikipage-content-timeline">
                    <h2>${section.title}</h2>
                    <div class="wikipage-timeline">
                        ${await renderResolvedTimeline(section.content, pagedata)}
                    </div>
                </div>
            `;

        case 'img-table':
            return `
                <div class="wikipage-content-block wikipage-content-imgtable">
                    <h2>${section.title}</h2>
                    <div class="wikipage-imgtable">
                        ${await renderResolvedImgTable(section.content, pagedata)}
                    </div>
                </div>
            `;

        default:
            return '';
    }
}

async function fillComments(pagedata, commentSection) {
    if (!pagedata.comments) return;

    const comments = await Promise.all(pagedata.comments.map(async (comment) => {
        if (comment["MERGE:FROM"]) {
            comment = await mergeFromKeyPath(comment, pagedata);
        }
        return renderComment(comment, pagedata);
    }));

    commentSection.innerHTML += comments.join('');
}

async function renderComment(comment, pagedata) {
    const [profileContent, profileData] = await resolveContent(comment.by, pagedata, "", true);
    const profileImage = await getProfileImage(profileData);
    
    return `
        <div class="wikipage-comment-block">
            <div class="wikipage-comment-heading">
                <img src="${profileImage}" alt="${comment.by}" class="wikipage-comment-profileimg"/>
                <div class="wikipage-comment-profile">${profileContent}</div>
                <i class="wikipage-comment-posted wikipage-timestamp">${await renderResolvedDatetime(comment.posted, pagedata)}</i>
            </div>
            <div class="wikipage-comment-content">
                ${comment.title ? `<b class="wikipage-comment-title">${await renderResolvedText(comment.title, pagedata)}</b><br>` : ''}
                <span class="wikipage-comment-main">${await renderResolvedMarkdown(comment.content, pagedata)}</span>
                ${comment.note ? `<i class="wikipage-comment-note">${await renderResolvedText(comment.note, pagedata)}</i>` : ''}
            </div>
        </div>
    `;
}

async function getProfileImage(profileData) {
    if (!profileData) return '/assets/images/default_author.svg';
    
    const profileJson = await profileData[Object.keys(profileData)[0]][1].json();
    if (!profileJson.image) return '/assets/images/default_author.svg';
    
    if (!profileJson.image.includes('/')) {
        return `/profiles/${profileJson.name.startsWith('@') ? profileJson.name : '@' + profileJson.name}/${profileJson.image}`;
    }
    
    return profileJson.image;
}